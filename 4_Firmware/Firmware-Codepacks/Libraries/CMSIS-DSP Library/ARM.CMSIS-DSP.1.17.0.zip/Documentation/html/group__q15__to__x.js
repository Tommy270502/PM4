var group__q15__to__x =
[
    [ "arm_q15_to_f16", "group__q15__to__x.html#ga42f8a8b9e0fc22509d464b3aeacf649a", null ],
    [ "arm_q15_to_f64", "group__q15__to__x.html#ga4b88ee09ba0bbb7fccc6b9d4894d6a22", null ],
    [ "arm_q15_to_float", "group__q15__to__x.html#ga5a75381e7d63ea3a3a315344615281cf", null ],
    [ "arm_q15_to_q31", "group__q15__to__x.html#ga39647b2109a5c64a067b776302c4a083", null ],
    [ "arm_q15_to_q7", "group__q15__to__x.html#ga837ce281d0e2d5fc445c48334307db19", null ]
];