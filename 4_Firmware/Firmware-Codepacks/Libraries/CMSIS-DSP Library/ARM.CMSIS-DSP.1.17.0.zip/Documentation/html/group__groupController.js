var group__groupController =
[
    [ "Sine Cosine", "group__SinCos.html", "group__SinCos" ],
    [ "PID Motor Control", "group__PID.html", "group__PID" ],
    [ "Vector Park Transform", "group__park.html", "group__park" ],
    [ "Vector Inverse Park transform", "group__inv__park.html", "group__inv__park" ],
    [ "Vector Clarke Transform", "group__clarke.html", "group__clarke" ],
    [ "Vector Inverse Clarke Transform", "group__inv__clarke.html", "group__inv__clarke" ]
];