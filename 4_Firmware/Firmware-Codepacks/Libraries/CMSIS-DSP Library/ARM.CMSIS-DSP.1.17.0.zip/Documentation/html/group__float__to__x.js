var group__float__to__x =
[
    [ "arm_float_to_f16", "group__float__to__x.html#ga5e0636b1fa9640c3e192108e0c747830", null ],
    [ "arm_float_to_f64", "group__float__to__x.html#gab44eb2fa9c8aa1051bd669e7b824f74f", null ],
    [ "arm_float_to_q15", "group__float__to__x.html#gac7696e64963e5051ebb950c88c6ba186", null ],
    [ "arm_float_to_q31", "group__float__to__x.html#gaae21be47db707e79552f3e8221a48fb0", null ],
    [ "arm_float_to_q7", "group__float__to__x.html#ga63b7cef42a242f0be43376ba3380988d", null ]
];